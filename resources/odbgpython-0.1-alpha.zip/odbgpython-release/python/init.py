import os
import sys
import time
import _ollypluginapi
sys.path.append(ODBGPYTHON_PATH)
from ollypluginapi import *
from odbgpython_helpers import *



class MyStdOut:
    """
    Dummy file-like class that receives stout and stderr
    """
    def write(self, text):
        fixed = text.replace('\n', '')
        if fixed != '':
            _ollypluginapi.Addtolist(0, 0, fixed)

    def flush(self):
        pass

    def isatty(self):
        return False


sys.stdout = sys.stderr = MyStdOut()
sys.argv = [ "" ]





def addscriptpath(script):
    """Add the path part of the scriptfile to the system path to  allow modules to be loaded from the same place.

    Each path is added only once.
    """
    pathfound = 0

    scriptpath = os.path.dirname(script)

    for pathitem in sys.path:
        if pathitem == scriptpath:
            pathfound = 1
            break
    
    if pathfound == 0:
        sys.path.append(scriptpath)


def runscript(script):
    """Run a script."""
	
    addscriptpath(script)
    watchdog.reset()
    argv = sys.argv
    sys.argv = [ script ]
    execfile(script, globals())
    sys.argv = argv




#-------------------------------------------------------------
# Watchdog to catch runaway scripts after a specified timeout
#
# Usage: watchdog.install()
#        watchdog.activate(10) # Use 10-second timeout
#
# Note: The watchdog only works for code running inside functions, not in global/module namespace.         
#-------------------------------------------------------------
class WatchDog():
    """Python tracer-based watchdog class"""
    def __init__(self, timeout=10):
        self.timestamp = 0
        self.timeout = timeout
        self.installed = False
        self.active = False

    def install(self):
        """ Install the tracer function, required for the watchdog """
        if not self.installed:
            sys.settrace(self.tracer)
            self.installed = True

    def activate(self, timeout=None):
        """ Activate the watchdog, with optional timeout change """
        assert self.installed, "WatchDog must be installed before activating"
        if timeout:
            self.timeout = timeout
        self.reset()
        self.active = True

    def deactivate(self):
        """ Deactivate the watchdog """
        self.active = True

    def reset(self):
        """ Reset the timer, useful for long-running scripts """
        self.timestamp = time.clock()

    def tracer(self, frame, event, arg):
        """ Tracer function that receives the tracing events """
        if not self.active:
            return None
        return self.tracer

watchdog = WatchDog(10)

ollypython_paused_callbacks = []


def add_paused_handler(func):
    ollypython_paused_callbacks.append(func)

def remove_paused_handler_byname(funcname):
	flist = [ a.func_name for a in  ollypython_paused_callbacks[::-1] ]
	for a in range(len(flist)-1, -1, -1):
		if flist[a] == funcname:
			del ollypython_paused_callbacks[a]


def remove_paused_handler_byindex(funcindex):
	del ollypython_paused_callbacks[funcindex]

	
def list_paused_handlers():
	c=0
	print 'Pause function handlers installed'
	for func in ollypython_paused_callbacks:
		print "%02d: %s" %(c, func.func_name)
		c=c+1
	

def run_paused_callbacks(reason):
	for func in ollypython_paused_callbacks:
		func(reason)