from ollypluginapi import *
from struct import pack, unpack
from gc import collect as garbage_collect
# Changes to this require reload of plugin

string_max_size = 100 # size of data to read when checking for string - max size of string
string_min_length = 3 # minimum size of string
     
     
     
class OllyMemoryReadError(Exception):
	def __init__(self, message):
		self.message = message


class OllyMemoryWriteError(Exception):
	def __init__(self, message):
		self.message = message

		
		
def FindSequenceInSequence(data, searchval):
	"""Builds a generator of start positions of occurrences of sequence within a sequence"""
	# KnuthMorrisPratt - http://code.activestate.com/recipes/117214/

	searchval = list(searchval)

	shifts = [1] * (len(searchval) + 1)
	shift = 1
	for pos in range(len(searchval)):
		while shift <= pos and searchval[pos] != searchval[pos-shift]:
			shift += shifts[pos-shift]
		shifts[pos+1] = shift

	startPos = 0
	matchLen = 0
	for c in data:
		while matchLen == len(searchval) or matchLen >= 0 and searchval[matchLen] != c:
			startPos += shifts[matchLen]
			matchLen -= shifts[matchLen]
		matchLen += 1
		if matchLen == len(searchval):
			yield startPos
		

def GetRegister(register):
	if register == EIP:
		return Findthread(Getcputhreadid()).reg.ip
	else:
		return ulonga_getitem(Findthread(Getcputhreadid()).reg.r, register)


def ReadMem(address, size):
	data = new_bytea(size)
	mem_read = Readmemory(data, address, size, MM_RESILENT)
	if mem_read != size:
		raise OllyMemoryReadError('Fewer bytes than requested were read from 0x%08x' %(address) )
	out = [ None ] * size
	try:
		for no in range(0, size):
			out[no] = bytea_getitem(data, no)
	except:
		raise OllyMemoryReadError('Error reading memory at 0x%08x' %(address) )
	delete_bytea(data) # maybe not necessary due to Python garbage collection, but doing it anyway
	return out
		


def ReadLong(address):
	return unpack('<L', ''.join([ chr(a) for a in ReadMem(address, 4) ]))[0]
	
	
def ReadString(address):
	data = ReadMem(address, string_max_size)
	out = ''
	IsString = False
	for char in data:
		if char == 0:
			break
		if IstextA(chr(char)) == PLAINASCII:
			out+=chr(char)

	if len(out) > string_min_length:
		return out
	else: # half assed double byte character check, improve using IstextW and olly string read methods when time permits
		for a in range(0, len(data), 2):
			if data[a] == 0:
				break
			if IstextA(chr(data[a])) == PLAINASCII and data[a+1] == 0:
				out+=chr(data[a])
		if len(out) > string_min_length:
			return out
		else:
			return ''


def WriteMem(address, value):
	data = new_bytea(len(value))
	for a in range(0, len(value)):
		bytea_setitem(data, a, value[a])
	
	written = Writememory(data, address, len(value), MM_RESILENT)
	delete_bytea(data)
	if written != len(value):
		raise OllyMemoryWriteError("Could not write all data")
	else:
		return written

	
def StringToByteArray(input):
	return [ ord(a) for a in input ]

	

def ByteArrayToString(ba):
	return ''.join([ chr(a) for a in ba ])


def IsASCIIString(check):	
	for a in check:
		if ord(a) > 127:
			return False
	return True

def IsWideString(check):	
	for a in range(0, len(check), 2):
		if ord(check[a]) > 127 or ord(check[a+1]) != 0:
				return False
	return True

def IsString(check):
	if IsASCIIString(check) or IsWideString(check):
		return True
	else:
		return False
		
		
# currently this is a little slow and freezes the debugger while it runs...	
def FindInMemory(value, exitfirstmatch=False):
	"""Returns a list of memory addresses for a given value"""
	out = []
	memtable = Plugingetvalue(VAL_MEMORY)
	table1 = int_cast_t_tablep(memtable)

	
	for a in range(0, table1.data.n):
		memp = new_t_memoryp()	
		gs = Getsortedbyselection(table1.data, a)
		gsm = voidp_cast_t_memoryp(gs)
		fmem = Findmemory(gsm.base)
		try:
			memdata = ReadMem(fmem.base, fmem.size)
		except:
			continue
		for pos in FindSequenceInSequence(memdata, value):
			out.append(fmem.base + pos)
			if exitfirstmatch:
				return out
	garbage_collect() # force Python garbage collection
	return out