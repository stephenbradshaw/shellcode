#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <shlwapi.h>
#include <Python.h>
#include "plugin.h"

void init_ollypluginapi(void);

HINSTANCE hinst;
HWND hwmain;

static int initialized = 0;


int ExecFile(char *FileName)
{
	PyObject* PyFileObject = PyFile_FromString(FileName, "r");

	if (!PyFileObject) 
	{
		return 0;
	}

	if (PyRun_SimpleFile(PyFile_AsFile(PyFileObject), FileName) == 0)
 	{
		Py_DECREF(PyFileObject);
		return 1;
	}
	else
	{
		Py_DECREF(PyFileObject);
		return 0;
	}
}

BOOL FileExist(char *filename)
{
    char path[MAX_PATH];

    GetModuleFileName(hinst, path, MAX_PATH);
    PathRemoveFileSpec(path);
    strncat(path, "\\python\\", 8);
    strcat(path, filename);

    return PathFileExists(path);
}

BOOL OdbgPython_Init(void)
{
    char initfile[MAX_PATH];
    char tmp[MAX_PATH+16];
    BOOL result = 1;

    if (initialized == 1)
    {
        return TRUE;
    }

    Addtolist(0, 0, "OdbgPython");
	
	
    result &= FileExist("init.py");
    result &= FileExist("ollypluginapi.py");
    result &= FileExist("odbgpython_helpers.py");	
    

    if (!result)
    {
        Addtolist(0, -1, "  Put init.py, ollypluginapi.py and odbgpython_helpers.py in python subdirectory.");
        return FALSE;
    }

	
    Py_Initialize();

    if (!Py_IsInitialized())
    {
        Addtolist(0, -1, "  Could not initialise Python, ensure Python 2.7 is in your path.");
        return FALSE;
    }

    
	init_ollypluginapi();

    GetModuleFileName(hinst, initfile, MAX_PATH);
    PathRemoveFileSpec(initfile);
    strncat(initfile, "\\python", 7);

    snprintf(tmp, MAX_PATH+16, "ODBGPYTHON_PATH=\"%s\"", initfile);
    PyRun_SimpleString(tmp);

    strncat(initfile, "\\init.py", 8);

    if (!ExecFile(initfile))
    {
        Addtolist(0, -1, "  Could not run init.py");
        return FALSE;
    }
	

    initialized = 1;

    return TRUE;
}

void OdbgPython_Destroy(void)
{
	
    Py_Finalize();

    initialized = 0;
}

void OdbgPython_RunScript(char *script)
{
    char userscript[MAX_PATH];
    char slashpath[MAX_PATH+1];
    char statement[MAX_PATH+13];
    int validfile;
    char *scriptpath;
    int i;

    userscript[0] = '\0';

    if (script)
    {
        scriptpath = script;
    }
    else
    {
        scriptpath = userscript;

        validfile = Browsefilename("title", scriptpath, ".py", 1);

        if (!validfile)
        {
            return;
        }
    }

    for (i=0; scriptpath[i]; i++)
    {
        if (scriptpath[i] == '\\')
        {
            slashpath[i] = '/';
        }
        else
        {
            slashpath[i] = scriptpath[i];
        }
    }

    slashpath[i] = '\0';

    snprintf(statement, sizeof(statement), "runscript(\"%s\")", slashpath);
    PyRun_SimpleString(statement);
    
    if (PyErr_Occurred())
    {
        PyErr_Print();
    }
}

BOOL WINAPI DllEntryPoint(HINSTANCE hi,DWORD reason,LPVOID reserved)
{
    if (reason == DLL_PROCESS_ATTACH)
        hinst = hi;

    return TRUE;
};

extc int  _export cdecl ODBG_Plugindata(char shortname[32])
{
    strcpy(shortname,"OdbgPython");
    return PLUGIN_VERSION;
}

extc int  _export cdecl ODBG_Plugininit(int pluginversion,HWND hw,ulong *features)
{
    if (pluginversion < PLUGIN_VERSION)
        return -1;

    hwmain = hw;

    if (OdbgPython_Init())
    {
        return 0;
    }
    else
    {
        return -1;
    }
}


extc int  _export cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item)
{
    switch (origin)
    {
        case PM_MAIN:
            strcpy(data, "0 Python &file...,");            
            strcat(data, "1 &About");
            return 1;
        default:
            return 0;
    }
}

extc void _export cdecl ODBG_Pluginaction(int origin,int action,void *item)
{
    switch (origin)
    {
        case PM_MAIN:
            switch (action)
            {
                case 0:
                    OdbgPython_RunScript(NULL);
                    break;
                case 1:
                    MessageBox(hwmain, "OdbgPython runs python scripts in OllyDbg...", "OdbgPython", MB_OK|MB_ICONINFORMATION);
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }
}

extc void _export cdecl ODBG_Plugindestroy(void)
{
    OdbgPython_Destroy();
}


extc int  _export cdecl ODBG_Paused(int reason,t_reg *reg)
{
	//PyGILState_STATE gstate;
	//gstate = PyGILState_Ensure();
	char statement[30];
	
	// not passing *reg ATM since register info is available from threads, but can pass and cast in python if needed
	snprintf(statement, sizeof(statement), "run_paused_callbacks(%i)", reason);
    PyRun_SimpleString(statement);
    
    if (PyErr_Occurred())
    {
        PyErr_Print();
    }
	
	//PyGILState_Release(gstate);
	
	return 0;
    
}
