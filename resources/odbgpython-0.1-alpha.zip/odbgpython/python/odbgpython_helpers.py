from ollypluginapi import *
from struct import pack, unpack
# Changes to this require reload of plugin

string_max_size = 100 # size of data to read when checking for string - max size of string
string_min_length = 3 # minimum size of string
     
     
     
class OllyMemoryReadError(Exception):
	def __init__(self, message):
		self.message = message


def GetRegister(register):
	if register == EIP:
		return Findthread(Getcputhreadid()).reg.ip
	else:
		return ulonga_getitem(Findthread(Getcputhreadid()).reg.r, register)


def ReadMem(address, size):
	data = new_bytea(size)
	mem_read = Readmemory(data, address, size, MM_RESILENT)
	if mem_read != size:
		raise OllyMemoryReadError('Fewer bytes than requested were read from 0x%08x' %(address) )
	out = [ None ] * size
	try:
		for no in range(0, size):
			out[no] = bytea_getitem(data, no)
	except:
		raise OllyMemoryReadError('Error reading memory at 0x%08x' %(address) )
	return out
		


def ReadLong(address):
	return unpack('<L', ''.join([ chr(a) for a in ReadMem(address, 4) ]))[0]
	
	
def ReadString(address):
	data = ReadMem(address, string_max_size)
	out = ''
	IsString = False
	for char in data:
		if char == 0:
			break
		if IstextA(chr(char)) == PLAINASCII:
			out+=chr(char)

	if len(out) > string_min_length:
		return out
	else: # half assed double byte character check, improve using IstextW and olly string read methods when time permits
		for a in range(0, len(data), 2):
			if data[a] == 0:
				break
			if IstextA(chr(data[a])) == PLAINASCII and data[a+1] == 0:
				out+=chr(data[a])
		if len(out) > string_min_length:
			return out
		else:
			return ''
			
def ByteArrayToString(ba):
	return ''.join([ chr(a) for a in ba ])


def IsASCIIString(check):	
	for a in check:
		if ord(a) > 127:
			return False
	return True

def IsWideString(check):	
	for a in range(0, len(check), 2):
		if ord(check[a]) > 127 or ord(check[a+1]) != 0:
				return False
	return True

def IsString(check):
	if IsASCIIString(check) or IsWideString(check):
		return True
	else:
		return False